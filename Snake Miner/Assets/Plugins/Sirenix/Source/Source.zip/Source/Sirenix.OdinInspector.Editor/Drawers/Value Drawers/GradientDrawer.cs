//-----------------------------------------------------------------------
// <copyright file="GradientDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using UnityEngine;

    /// <summary>
    /// Gradient property drawer.
    /// </summary>
    public class GradientDrawer : DrawWithUnityBaseDrawer<Gradient>
    {
    }
}
#endif