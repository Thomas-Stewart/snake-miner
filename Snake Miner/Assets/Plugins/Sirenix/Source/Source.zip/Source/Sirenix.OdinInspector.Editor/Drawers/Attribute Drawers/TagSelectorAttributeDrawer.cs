//-----------------------------------------------------------------------
// <copyright file="TagSelectorAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
//namespace Sirenix.OdinInspector.Editor.Drawers
//{
//    using System.Linq;
//    using Sirenix.Utilities;
//    using Sirenix.Utilities.Editor;
//    using UnityEngine;

//    /// <summary>
//    /// Draws a dropdown for string properties with the TagSelector attribute.
//    /// </summary>
//    public class TagSelectorAttributeDrawer : OdinAttributeDrawer<TagSelectorAttribute, string>
//    {
//        private bool currentValueMissing;
//        private string[] tags = null;

//        private void RefreshTagList()
//        {
//            this.tags = UnityEditorInternal.InternalEditorUtility.tags;
//        }

//        /// <summary>
//        /// Initializes the drawer.
//        /// </summary>
//        protected override void Initialize()
//        {
//            RefreshTagList();
//        }

//        /// <summary>
//        /// Draws the property.
//        /// </summary>
//        protected override void DrawPropertyLayout(GUIContent label)
//        {
//            if (Event.current.type == EventType.Layout)
//            {
//                this.currentValueMissing = string.IsNullOrEmpty(this.ValueEntry.SmartValue) == false && this.tags.Contains(this.ValueEntry.SmartValue) == false;
//            }

//            if (this.currentValueMissing)
//            {
//                SirenixEditorGUI.ErrorMessageBox("The tag '" + this.ValueEntry.SmartValue + "' does not exist.");
//            }
            
//            var result = GenericSelector<string>.DrawSelectorDropdown(
//                label,
//                string.IsNullOrEmpty(this.ValueEntry.SmartValue) ? "<No tag>" : this.ValueEntry.SmartValue,
//                this.CreateSelector,
//                SirenixGUIStyles.Popup);

//            if (result != null)
//            {
//                this.ValueEntry.SmartValue = result.FirstOrDefault();
//            }
//        }

//        private OdinSelector<string> CreateSelector(Rect position)
//        {
//            this.RefreshTagList();
//            var selector = new GenericSelector<string>(this.tags);

//            if (this.tags.Contains(this.ValueEntry.SmartValue))
//            {
//                selector.SetSelection(this.ValueEntry.SmartValue);
//            }

//            selector.ShowInPopup(position);

//            return selector;
//        }
//    }
//}
#endif