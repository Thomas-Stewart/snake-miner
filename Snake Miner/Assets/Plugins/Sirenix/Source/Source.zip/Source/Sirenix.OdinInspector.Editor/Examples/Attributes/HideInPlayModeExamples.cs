//-----------------------------------------------------------------------
// <copyright file="HideInPlayModeExamples.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Examples
{
    [AttributeExample(typeof(HideInPlayModeAttribute))]
    internal class HideInPlayModeExamples
    {
        public int AlwaysVisible;

        [Title("Hidden in play mode")]
        [HideInPlayMode]
        public int A;

        [HideInPlayMode]
        public int B;
    }
}
#endif