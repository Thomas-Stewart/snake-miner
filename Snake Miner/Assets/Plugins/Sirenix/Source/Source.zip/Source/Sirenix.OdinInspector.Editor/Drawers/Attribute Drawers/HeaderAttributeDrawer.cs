//-----------------------------------------------------------------------
// <copyright file="HeaderAttributeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using Sirenix.OdinInspector.Editor;
    using Sirenix.OdinInspector.Editor.ValueResolvers;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Draws properties marked with <see cref="HeaderAttribute"/>.
    /// </summary>
    /// <seealso cref="HeaderAttribute"/>
    /// <seealso cref="TitleAttribute"/>
    /// <seealso cref="HideLabelAttribute"/>
    /// <seealso cref="LabelTextAttribute"/>
    /// <seealso cref="SpaceAttribute"/>
    [DrawerPriority(1, 0, 0)]
    public sealed class HeaderAttributeDrawer : OdinAttributeDrawer<HeaderAttribute>
    {
        private ValueResolver<string> textResolver;

        protected override void Initialize()
        {
            // Don't draw for collection elements
            if (this.Property.Parent != null && this.Property.Parent.ChildResolver is ICollectionResolver)
            {
                this.SkipWhenDrawing = true;
                return;
            }

            this.textResolver = ValueResolver.GetForString(this.Property, this.Attribute.header);
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (this.Property != this.Property.Tree.GetRootProperty(0))
            {
                EditorGUILayout.Space();
            }

            if (this.textResolver.HasError)
            {
                SirenixEditorGUI.ErrorMessageBox(this.textResolver.ErrorMessage);
            }
            else
            {
                EditorGUILayout.LabelField(this.textResolver.GetValue(), EditorStyles.boldLabel);
            }

            this.CallNextDrawer(label);
        }
    }
}
#endif