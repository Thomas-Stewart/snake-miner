//-----------------------------------------------------------------------
// <copyright file="EnumPagingAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector
{
    using System;

    /// <summary>
    /// <para>Draws an enum selector in the inspector with next and previous buttons to let you cycle through the available values for the enum property.</para>
    /// </summary>
    /// <example>
    /// <code>
    /// public enum MyEnum
    /// {
    ///     One,
    ///     Two,
    ///     Three,
    /// }
    /// 
    /// public class MyMonoBehaviour : MonoBehaviour
    /// {
    ///     [EnumPaging]
    ///     public MyEnum Value;
    /// }
    /// </code>
    /// </example>
    /// <seealso cref="System.Attribute" />
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false)]
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public class EnumPagingAttribute : Attribute
    {
    }
}
#endif