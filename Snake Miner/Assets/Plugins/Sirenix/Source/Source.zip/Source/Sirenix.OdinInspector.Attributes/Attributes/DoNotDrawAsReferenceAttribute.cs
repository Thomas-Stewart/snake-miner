//-----------------------------------------------------------------------
// <copyright file="DoNotDrawAsReferenceAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector
{
    using System;

    /// <summary>
    /// Indicates that the member should not be drawn as a value reference, if it becomes a reference to another value in the tree. Beware, and use with care! This may lead to infinite draw loops!
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class DoNotDrawAsReferenceAttribute : Attribute
    {
    }
}
#endif