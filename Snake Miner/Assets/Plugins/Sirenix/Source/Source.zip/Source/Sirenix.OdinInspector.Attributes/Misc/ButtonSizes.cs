//-----------------------------------------------------------------------
// <copyright file="ButtonSizes.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector
{
    /// <summary>
    /// Various built-in button sizes.
    /// </summary>
    public enum ButtonSizes
    {
        /// <summary>
        /// Small button size, fits well with properties in the inspector.
        /// </summary>
        Small = 0,

        /// <summary>
        /// A larger button.
        /// </summary>
        Medium = 22,

        /// <summary>
        /// A very large button. 
        /// </summary>
        Large = 31,

        /// <summary>
        /// A gigantic button. Twice as big as Large 
        /// </summary>
        Gigantic = 62,
    }
}
#endif