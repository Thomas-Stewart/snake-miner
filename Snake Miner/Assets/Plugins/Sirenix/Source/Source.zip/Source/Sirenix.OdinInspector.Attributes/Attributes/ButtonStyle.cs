//-----------------------------------------------------------------------
// <copyright file="ButtonStyle.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector
{
    /// <summary>
    /// Button style for methods with parameters.
    /// </summary>
    public enum ButtonStyle
    {
        /// <summary>
        /// Draws a foldout box around the parameters of the method with the button on the box header itself.
        /// This is the default style of a method with parameters.
        /// </summary>
        CompactBox,

        /// <summary>
        /// Draws a button with a foldout to expose the parameters of the method.
        /// </summary>
        FoldoutButton,

        /// <summary>
        /// Draws a foldout box around the parameters of the method with the button at the bottom of the box.
        /// </summary>
        Box,
    }
}
#endif