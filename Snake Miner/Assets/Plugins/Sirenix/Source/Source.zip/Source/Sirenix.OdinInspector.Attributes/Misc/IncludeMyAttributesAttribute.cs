//-----------------------------------------------------------------------
// <copyright file="IncludeMyAttributesAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector
{
    using System;

    /// <summary>
    /// When this attribute is added is added to another attribute, then attributes from that attribute
    /// will also be added to the property in the attribute processing step.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class IncludeMyAttributesAttribute : Attribute
    {
    }
}
#endif