//-----------------------------------------------------------------------
// <copyright file="DisableInAttribute.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
using System;

namespace Sirenix.OdinInspector
{
    /// <summary>
    /// Disables a member based on which type of a prefab and instance it is in. 
    /// </summary>
    [DontApplyToListElements]
    [AttributeUsage(AttributeTargets.All)]
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public class DisableInAttribute : Attribute
    {
        public PrefabKind PrefabKind;

        public DisableInAttribute(PrefabKind prefabKind)
        {
            this.PrefabKind = prefabKind;
        }
    }
}
#endif